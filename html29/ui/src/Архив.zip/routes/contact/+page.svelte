<svelte:head>
  <title>Contact</title>
</svelte:head>
<header>
    <h1>Home</h1>
</header>
    <p>You can contact me here.</p> 
    <footer>
      <nav>
        <li><a href="/">Home</a></li>
        <li><a href="/about">About</a></li>   
        <li><a href="/contact">Contact</a></li>
      </nav>
    </footer>

  