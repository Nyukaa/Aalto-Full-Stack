<svelte:head>
  <title>Home</title>
</svelte:head>
<header>
    <h1>Home</h1>
</header>
    <p>Hello world!</p>
<footer>
    
    
</footer>   
