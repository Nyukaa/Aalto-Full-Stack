<svelte:head>
  <title>Contact</title>
</svelte:head>
<header>
    <h1>Contact</h1>
</header>
    <p>You can contact me here.</p>
    <footer>
 
    </footer>   


  