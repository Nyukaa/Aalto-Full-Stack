<svelte:head>
  <title>Contact</title>
</svelte:head>
<body>
    <header>
      <h1>Contact</h1>
    </header>
    <p>You can contact me here.</p>
    <footer>
    <li><a href="/">Home</a></li>
    <li><a href="/about">About</a></li>   
    <li><a href="/contact">Contact</a></li>
    </footer>   
</body> 

  