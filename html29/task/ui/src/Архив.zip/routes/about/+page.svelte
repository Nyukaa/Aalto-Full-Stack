<svelte:head>
  <title>About</title>
</svelte:head>

<header>
    <h1>About</h1>
</header>
    <p>This is my about page!</p>
    <footer>
      <nav>
        <li><a href="/">Home</a></li>
        <li><a href="/about">About</a></li>   
        <li><a href="/contact">Contact</a></li>
      </nav>
    </footer>
