<footer class="footer footer-center p-4 bg-base-300 text-base-content">
    <aside>
      <p>My application is cool.</p>
    </aside>
  </footer>