<script>
    import BookList from '$lib/components/book-management/BookList.svelte';
    import AddBook from '$lib/components/book-management/AddBook.svelte';
  </script>
  
  <AddBook />
  <BookList />
  