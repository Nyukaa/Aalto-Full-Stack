const names = [];

const getNames = () => {
  return names;
};

const addName = (name) => {
  names.push(name);
};

export { addName, getNames };
